<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title></title>
</head>
<body>
	<p>Hi, This is <?php echo e($contact['name']); ?></p>
</body>
</html><?php /**PATH /home/kryme/Documents/TransWeb/resources/views/mail.blade.php ENDPATH**/ ?>