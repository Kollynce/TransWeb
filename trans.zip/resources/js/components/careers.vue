<template>
    <div>
        <!-- Breadcrumbs-->
        <section class="breadcrumbs-custom">
            <div class="container">
                <ul class="breadcrumbs-custom-path">
                    <li><router-link to="/">Home</router-link></li>
                    <li class="active">Careers</li>
                </ul>
            </div>
        </section>
        <div class="container grid-demo grid-demo-underlined">
            <h3 class="text-center pt-4">Careers</h3>
            <div class="row justify-content-center">
                <div class="col-10 justify-content-center">
                    <p class="text-center lead">We are a global team dedicated to the belief that brilliance is evenly distributed. We are problem solvers, team builders, techies (and non-techies!) who work together across borders to power today’s engineering teams and invest in tomorrow’s leaders. We bridge the divide between the U.S. and African tech sectors, and we couldn’t do it without amazing talent. </p>
                </div>
            </div>
            <div class="row">
                <div class="col-8">
                    <h4>Hire the best people and trust them to do the right thing.</h4>
                    <p>Welcome to our wonderful world. We sincerely hope that each and every user entering our website will find exactly what he/she is looking for. With advanced features of activating account and new login widgets, you will definitely have a great experience of using our web page. It will tell you</p>
                </div>
                <div class="col-4">
                    <h6>// Aretha_Kebirungi, Senior Software Engineer</h6>
                    <p>Welcome to our wonderful world. We sincerely hope that each and every user entering our website will find exactly what he/she is looking for.</p>
                </div>
            </div>
            <div class="container">
                <h4 class="text-center pt-4">Locations</h4>
                <div class="row row-50">
                    <div class="col-sm-6 col-lg-4 text-center text-sm-left wow fadeInRight" data-wow-delay=".4s" style="visibility: visible; animation-delay: 0.4s; animation-name: fadeInRight;"><a class="overlay-img" href="blog-post.html"><img src="assets/images/news-image-03-370x260.jpg" alt="img" width="370" height="260"></a>
                        <h5 class="font-weight-sbold ls-1 pt-2"><a href="blog-post.html">Nairobi</a></h5>
                    </div>
                    <div class="col-sm-6 col-lg-4 text-center text-sm-left wow fadeInRight" data-wow-delay=".4s" style="visibility: visible; animation-delay: 0.4s; animation-name: fadeInRight;"><a class="overlay-img" href="blog-post.html"><img src="assets/images/news-image-03-370x260.jpg" alt="img" width="370" height="260"></a>
                        <h5 class="font-weight-sbold ls-1 pt-2"><a href="blog-post.html">Eldoret</a></h5>
                    </div>
                    <div class="col-sm-6 col-lg-4 text-center text-sm-left wow fadeInRight" data-wow-delay=".4s" style="visibility: visible; animation-delay: 0.4s; animation-name: fadeInRight;"><a class="overlay-img" href="blog-post.html"><img src="assets/images/news-image-03-370x260.jpg" alt="img" width="370" height="260"></a>
                        <h5 class="font-weight-sbold ls-1 pt-2"><a href="blog-post.html">Kisumu</a></h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        mounted() {
            console.log('Component mounted.')
        }
    }
</script>

<style scoped>
    
</style>
