<template>
    <div>
        <section class="breadcrumbs-custom">
            <div class="container">
                <ul class="breadcrumbs-custom-path">
                    <li><a href="home">Home</a></li>
                    <li><a href="services">Services</a></li>
                    <li class="active">Internet Of Things</li>
                </ul>
            </div>
        </section>
        <section class="section section-md bg-default">
            <div class="container">
                <div class="row row-50">
                    <div class="col-lg-8"><img src="/images/blur.jpg" alt="img" width="770" height="500">
                        <h2 class="font-weight-sbold wow fadeIn offset-top-40" data-wow-delay=".2s" style="visibility: visible; animation-delay: 0.2s; animation-name: fadeIn;">Internet Of Things</h2>
                        <h4 class="font-weight-light text-gray-650 lh-3"> From smart buildings to smart cities, IoT is transforming industries at a rapid pace. Organizations seek to enter new markets, create disruptive business models, develop new products or drive differentiated customer experiences with IoT. IoT is making the world smarter and better than than ever.</h4>
                        <h4 class="font-weight-light text-gray-650 lh-3"> Transonline Web Internet of Things service enables organizations to transform business needs into competitive space by delivering innovative IoT powered solutions. From integrating the right sensors and deriving inspired insights to choosing the best-fit platform, we provide comprehensive IoT services to our clients. </h4>
                        <!-- <ul class="list-custom-3 heading-4 font-weight-light text-gray-650 lh-3">
                            <li>› Brute fuisset eos definiebas</li>
                            <li>› Euismod appetere</li>
                            <li>› Melius corpora consulatu</li>
                            <li>› Torquatos deseruisse</li>
                        </ul> -->
                        
                    </div>
                    <div class="col-lg-4"><a class="box-lola-wrapper" href="#">
                        <div class="box-lola">
                            <div class="small-text font-weight-sbold ls-1 lh-4"> Software Development</div>
                        </div></a><a class="box-lola-wrapper" href="#">
                        <div class="box-lola">
                            <div class="small-text font-weight-sbold ls-1 lh-4"> Web Design & Development</div>
                        </div></a><a class="box-lola-wrapper" href="#">
                        <div class="box-lola">
                            <div class="small-text font-weight-sbold ls-1 lh-4">Mobile App Development</div>
                        </div></a><a class="box-lola-wrapper" href="#">
                        <div class="box-lola">
                            <div class="small-text font-weight-sbold ls-1 lh-4"> Web Portals</div>
                        </div></a><a class="box-lola-wrapper" href="#">
                        <div class="box-lola">
                            <div class="small-text font-weight-sbold ls-1 lh-4"> Internet of Things</div>
                        </div></a>
                        <a class="box-lola-wrapper" href="#">
                            <div class="box-lola">
                                <div class="small-text font-weight-sbold ls-1 lh-4"> Web Apps Development</div>
                            </div>
                        </a>
                        <a class="box-lola-wrapper" href="#">
                            <div class="box-lola">
                                <div class="small-text font-weight-sbold ls-1 lh-4"> Artificial Inteligence</div>
                            </div>
                        </a>
                        <a class="box-lola-wrapper" href="#">
                            <div class="box-lola">
                                <div class="small-text font-weight-sbold ls-1 lh-4"> Big Data</div>
                            </div>
                        </a>
                        <a class="box-lola-wrapper" href="#">
                            <div class="box-lola">
                                <div class="small-text font-weight-sbold ls-1 lh-4"> Search Engine Optimization</div>
                            </div>
                        </a>
                        <div class="box-tina">
                            <div class="small-text text-third font-weight-sbold lh-4">Still have questions?</div>
                            <div class="box-tina-block">
                                <div class="box-tina-block-icon">
                                    <svg width="36" height="37" viewBox="0 0 36 37" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M30.3053 22.0558C29.5195 21.2186 28.5717 20.7711 27.5673 20.7711C26.5709 20.7711 25.615 21.2103 24.7969 22.0475L22.2371 24.6584C22.0265 24.5423 21.8158 24.4346 21.6133 24.3268C21.3217 24.1776 21.0463 24.0367 20.8114 23.8875C18.4136 22.3293 16.2345 20.2986 14.1446 17.6711C13.132 16.3616 12.4516 15.2592 11.9574 14.1402C12.6217 13.5186 13.2373 12.8721 13.8368 12.2504C14.0636 12.0184 14.2904 11.778 14.5172 11.5459C16.2183 9.80533 16.2183 7.55085 14.5172 5.81026L12.3057 3.54749C12.0546 3.29055 11.7954 3.02531 11.5524 2.76008C11.0663 2.24619 10.556 1.71573 10.0295 1.21841C9.24372 0.422715 8.30405 0 7.31577 0C6.3275 0 5.37163 0.422715 4.56157 1.21841C4.55347 1.2267 4.55347 1.2267 4.54537 1.23499L1.79116 4.07796C0.754286 5.13889 0.162942 6.4319 0.0333328 7.93212C-0.161082 10.3524 0.53557 12.6069 1.07021 14.0822C2.38251 17.7043 4.34285 21.0612 7.26717 24.6584C10.8152 28.9933 15.0842 32.4164 19.9608 34.8284C21.8239 35.7319 24.3108 36.8011 27.0893 36.9834C27.2595 36.9917 27.4377 37 27.5997 37C29.4709 37 31.0424 36.312 32.2737 34.9444C32.2818 34.9279 32.298 34.9196 32.3061 34.903C32.7274 34.3808 33.2134 33.9084 33.7237 33.4028C34.0721 33.0629 34.4285 32.7065 34.7768 32.3336C35.5788 31.4798 36 30.4852 36 29.4657C36 28.4379 35.5707 27.4516 34.7525 26.6228L30.3053 22.0558ZM33.2053 30.7836C33.1972 30.7836 33.1972 30.7919 33.2053 30.7836C32.8894 31.1317 32.5653 31.4467 32.217 31.7948C31.6905 32.3087 31.1558 32.8474 30.6536 33.4525C29.8354 34.3477 28.8715 34.7704 27.6078 34.7704C27.4863 34.7704 27.3567 34.7704 27.2351 34.7621C24.8293 34.6046 22.5935 33.6431 20.9167 32.8226C16.3317 30.5515 12.3057 27.3273 8.96019 23.241C6.19789 19.8345 4.35095 16.6848 3.12776 13.3031C2.37441 11.2392 2.09899 9.63127 2.22049 8.11447C2.3015 7.14471 2.66603 6.34073 3.33838 5.65278L6.10068 2.82639C6.49761 2.44512 6.91884 2.2379 7.33197 2.2379C7.84231 2.2379 8.25544 2.55287 8.51466 2.8181C8.52276 2.82639 8.53086 2.83468 8.53896 2.84297C9.0331 3.31541 9.50293 3.80444 9.99707 4.32661C10.2482 4.59185 10.5074 4.85708 10.7666 5.1306L12.9781 7.39337C13.8368 8.27195 13.8368 9.08423 12.9781 9.96281C12.7432 10.2032 12.5164 10.4435 12.2814 10.6756C11.601 11.3884 10.9529 12.0515 10.2482 12.698C10.232 12.7146 10.2158 12.7229 10.2077 12.7395C9.51104 13.4523 9.64065 14.1485 9.78646 14.621C9.79456 14.6458 9.80266 14.6707 9.81076 14.6956C10.3859 16.1212 11.196 17.4639 12.4273 19.0636L12.4354 19.0719C14.6711 21.89 17.0284 24.0865 19.6287 25.769C19.9608 25.9845 20.301 26.1586 20.6251 26.3244C20.9167 26.4736 21.1921 26.6145 21.427 26.7637C21.4594 26.7802 21.4918 26.8051 21.5242 26.8217C21.7996 26.9626 22.0589 27.0289 22.3262 27.0289C22.9985 27.0289 23.4198 26.5979 23.5575 26.457L26.3279 23.6223C26.6033 23.3405 27.0407 23.0007 27.5511 23.0007C28.0533 23.0007 28.4664 23.3239 28.7176 23.6057C28.7257 23.614 28.7257 23.614 28.7338 23.6223L33.1972 28.1893C34.0316 29.0347 34.0316 29.905 33.2053 30.7836Z" fill="#4173F2"></path>
                                    </svg>
                                </div>
                                <div class="box-tina-block-text">
                                    <h6 class="font-weight-light text-gray-680">Phone</h6>
                                    <h4><a href="tel:#">+254748621900</a></h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</template>

<script>
    export default {
        mounted() {
            console.log('Component mounted.')
        }
    }
</script>
