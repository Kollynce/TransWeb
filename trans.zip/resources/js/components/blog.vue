<template>
    <div>
       <section class="section section-md bg-default">
            <div class="container">
                <div class="row row-50">
                    <div class="col-sm-6 col-lg-4 text-center text-sm-left wow fadeInRight" data-wow-delay=".2s" style="visibility: visible; animation-delay: 0.2s; animation-name: fadeInRight;"><a class="overlay-img" href="blog-post.html"><img src="assets/images/news-image-01-370x260.jpg" alt="img" width="370" height="260"></a>
                        <div class="small-text font-weight-light text-gray-650 offset-top-30">March 2, 2019</div>
                        <h5 class="font-weight-sbold ls-1"><a href="blog-post.html">Achieving Success as a Business Owner</a></h5><a class="button button-icon button-icon-right text-primary button-lg" href="blog-post.html"><span>Learn More</span><span class="arrow">
                      <svg width="11" height="7" viewBox="0 0 11 7" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M7.29111 0.146484C7.48168 -0.048828 7.79084 -0.048828 7.98142 0.146484L10.8571 3.09173C10.9196 3.15582 10.9617 3.23296 10.9832 3.31457C11.0026 3.38842 11.0052 3.466 10.991 3.54082C10.9736 3.63671 10.9295 3.72845 10.8571 3.8026L7.98142 6.85356C7.79084 7.04881 7.48168 7.04881 7.29111 6.85356C7.10042 6.65825 7.10042 6.34172 7.29111 6.14641L9.42663 3.85357H0.488175C0.218583 3.85357 1.7879e-06 3.62969 1.7879e-06 3.35357C1.7879e-06 3.07745 0.218583 2.85357 0.488175 2.85357H9.24368L7.29111 0.853575C7.10042 0.658324 7.10042 0.341735 7.29111 0.146484Z" fill="#4173F2"></path>
                      </svg></span></a>
                    </div>
                    <div class="col-sm-6 col-lg-4 text-center text-sm-left wow fadeInRight" data-wow-delay=".3s" style="visibility: visible; animation-delay: 0.3s; animation-name: fadeInRight;"><a class="overlay-img" href="blog-post.html"><img src="assets/images/news-image-02-370x260.jpg" alt="img" width="370" height="260"></a>
                        <div class="small-text font-weight-light text-gray-650 offset-top-30">March 2, 2019</div>
                        <h5 class="font-weight-sbold ls-1"><a href="blog-post.html">Top 12 Ideas for Your Business</a></h5><a class="button button-icon button-icon-right text-primary button-lg" href="blog-post.html"><span>Learn More</span><span class="arrow">
                      <svg width="11" height="7" viewBox="0 0 11 7" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M7.29111 0.146484C7.48168 -0.048828 7.79084 -0.048828 7.98142 0.146484L10.8571 3.09173C10.9196 3.15582 10.9617 3.23296 10.9832 3.31457C11.0026 3.38842 11.0052 3.466 10.991 3.54082C10.9736 3.63671 10.9295 3.72845 10.8571 3.8026L7.98142 6.85356C7.79084 7.04881 7.48168 7.04881 7.29111 6.85356C7.10042 6.65825 7.10042 6.34172 7.29111 6.14641L9.42663 3.85357H0.488175C0.218583 3.85357 1.7879e-06 3.62969 1.7879e-06 3.35357C1.7879e-06 3.07745 0.218583 2.85357 0.488175 2.85357H9.24368L7.29111 0.853575C7.10042 0.658324 7.10042 0.341735 7.29111 0.146484Z" fill="#4173F2"></path>
                      </svg></span></a>
                    </div>
                    <div class="col-sm-6 col-lg-4 text-center text-sm-left wow fadeInRight" data-wow-delay=".4s" style="visibility: visible; animation-delay: 0.4s; animation-name: fadeInRight;"><a class="overlay-img" href="blog-post.html"><img src="assets/images/news-image-03-370x260.jpg" alt="img" width="370" height="260"></a>
                        <div class="small-text font-weight-light text-gray-650 offset-top-30">March 2, 2019</div>
                        <h5 class="font-weight-sbold ls-1"><a href="blog-post.html">Why Business Planning is Important</a></h5><a class="button button-icon button-icon-right text-primary button-lg" href="blog-post.html"><span>Learn More</span><span class="arrow">
                      <svg width="11" height="7" viewBox="0 0 11 7" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M7.29111 0.146484C7.48168 -0.048828 7.79084 -0.048828 7.98142 0.146484L10.8571 3.09173C10.9196 3.15582 10.9617 3.23296 10.9832 3.31457C11.0026 3.38842 11.0052 3.466 10.991 3.54082C10.9736 3.63671 10.9295 3.72845 10.8571 3.8026L7.98142 6.85356C7.79084 7.04881 7.48168 7.04881 7.29111 6.85356C7.10042 6.65825 7.10042 6.34172 7.29111 6.14641L9.42663 3.85357H0.488175C0.218583 3.85357 1.7879e-06 3.62969 1.7879e-06 3.35357C1.7879e-06 3.07745 0.218583 2.85357 0.488175 2.85357H9.24368L7.29111 0.853575C7.10042 0.658324 7.10042 0.341735 7.29111 0.146484Z" fill="#4173F2"></path>
                      </svg></span></a>
                    </div>
                </div>
            </div>
       </section>
    </div>
</template>

<script>
    export default {
        mounted() {
            console.log('Component mounted.')
        }
    }
</script>
