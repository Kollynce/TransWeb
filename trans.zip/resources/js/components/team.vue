<template>
    <div>
        <!-- Breadcrumbs-->
        <section class="breadcrumbs-custom">
            <div class="container">
                <ul class="breadcrumbs-custom-path">
                    <li><router-link to="/">Home</router-link></li>
                    <li class="active">Team</li>
                </ul>
            </div>
        </section>
        <!-- Our Team -->
        <section class="section section-md bg-default">
            <div class="container">
                <div class="row row-40">
                    <div class="col-sm-6 col-md-4 box-team">
                        <div class="item item-right">
                            <div class="item-block-img"><img src="assets/images/owl-carousel-image-1-270x320.jpg" alt="img" width="270" height="320">
                            </div>
                            <div class="item-block-social">
                                <ul>
                                    <li><a class="text-gray-270" href="#"><span class="icon mdi mdi-facebook icon-sm"></span></a></li>
                                    <li><a class="text-gray-270" href="#"><span class="icon mdi mdi-twitter icon-sm"></span></a></li>
                                    <li><a class="text-gray-270" href="#"><span class="icon mdi mdi-instagram icon-xs"></span></a></li>
                                </ul>
                            </div>
                            <h5 class="font-weight-sbold ls-1 text-center offset-top-15">Rewel Adedi</h5>
                            <div class="small-text font-weight-light text-center">CEO</div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-4 col-xl-3 box-team">
                        <div class="item">
                            <div class="item-block-img"><img src="assets/images/owl-carousel-image-2-270x320.jpg" alt="img" width="270" height="320">
                            </div>
                            <div class="item-block-social">
                                <ul>
                                    <li><a class="text-gray-270" href="#"><span class="icon mdi mdi-facebook icon-sm"></span></a></li>
                                    <li><a class="text-gray-270" href="#"><span class="icon mdi mdi-twitter icon-sm"></span></a></li>
                                    <li><a class="text-gray-270" href="#"><span class="icon mdi mdi-instagram icon-xs"></span></a></li>
                                </ul>
                            </div>
                            <h5 class="font-weight-sbold ls-1 text-center offset-top-15">Josiah Bwonda</h5>
                            <div class="small-text font-weight-light text-center">General Manager</div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-4 box-team">
                        <div class="item item-left">
                            <div class="item-block-img"><img src="assets/images/owl-carousel-image-3-270x320.jpg" alt="img" width="270" height="320">
                            </div>
                            <div class="item-block-social">
                                <ul>
                                    <li><a class="text-gray-270" href="#"><span class="icon mdi mdi-facebook icon-sm"></span></a></li>
                                    <li><a class="text-gray-270" href="#"><span class="icon mdi mdi-twitter icon-sm"></span></a></li>
                                    <li><a class="text-gray-270" href="#"><span class="icon mdi mdi-instagram icon-xs"></span></a></li>
                                </ul>
                            </div>
                            <h5 class="font-weight-sbold ls-1 text-center offset-top-15">Morris Mwendwa</h5>
                            <div class="small-text font-weight-light text-center">Head of Marketing</div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-4 box-team">
                        <div class="item item-right">
                            <div class="item-block-img"><img src="assets/images/owl-carousel-image-4-270x320.jpg" alt="img" width="270" height="320">
                            </div>
                            <div class="item-block-social">
                                <ul>
                                    <li><a class="text-gray-270" href="#"><span class="icon mdi mdi-facebook icon-sm"></span></a></li>
                                    <li><a class="text-gray-270" href="#"><span class="icon mdi mdi-twitter icon-sm"></span></a></li>
                                    <li><a class="text-gray-270" href="#"><span class="icon mdi mdi-instagram icon-xs"></span></a></li>
                                </ul>
                            </div>
                            <h5 class="font-weight-sbold ls-1 text-center offset-top-15">Viena Kaseke</h5>
                            <div class="small-text font-weight-light text-center">Director</div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-4 col-xl-3 box-team">
                        <div class="item">
                            <div class="item-block-img"><img src="assets/images/owl-carousel-image-5-270x320.jpg" alt="img" width="270" height="320">
                            </div>
                            <div class="item-block-social">
                                <ul>
                                    <li><a class="text-gray-270" href="#"><span class="icon mdi mdi-facebook icon-sm"></span></a></li>
                                    <li><a class="text-gray-270" href="#"><span class="icon mdi mdi-twitter icon-sm"></span></a></li>
                                    <li><a class="text-gray-270" href="#"><span class="icon mdi mdi-instagram icon-xs"></span></a></li>
                                </ul>
                            </div>
                            <h5 class="font-weight-sbold ls-1 text-center offset-top-15">Joe Nelson</h5>
                            <div class="small-text font-weight-light text-center">Head of Support</div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-4 box-team">
                        <div class="item item-left">
                            <div class="item-block-img"><img src="assets/images/owl-carousel-image-6-270x320.jpg" alt="img" width="270" height="320">
                            </div>
                            <div class="item-block-social">
                                <ul>
                                    <li><a class="text-gray-270" href="#"><span class="icon mdi mdi-facebook icon-sm"></span></a></li>
                                    <li><a class="text-gray-270" href="#"><span class="icon mdi mdi-twitter icon-sm"></span></a></li>
                                    <li><a class="text-gray-270" href="#"><span class="icon mdi mdi-instagram icon-xs"></span></a></li>
                                </ul>
                            </div>
                            <h5 class="font-weight-sbold ls-1 text-center offset-top-15">Maria Price</h5>
                            <div class="small-text font-weight-light text-center">Business Consultant</div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-4 box-team">
                        <div class="item item-right">
                            <div class="item-block-img"><img src="assets/images/owl-carousel-image-7-270x320.jpg" alt="img" width="270" height="320">
                            </div>
                            <div class="item-block-social">
                                <ul>
                                    <li><a class="text-gray-270" href="#"><span class="icon mdi mdi-facebook icon-sm"></span></a></li>
                                    <li><a class="text-gray-270" href="#"><span class="icon mdi mdi-twitter icon-sm"></span></a></li>
                                    <li><a class="text-gray-270" href="#"><span class="icon mdi mdi-instagram icon-xs"></span></a></li>
                                </ul>
                            </div>
                            <h5 class="font-weight-sbold ls-1 text-center offset-top-15">Gerald Scott</h5>
                            <div class="small-text font-weight-light text-center">Strategist</div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-4 col-xl-3 box-team">
                        <div class="item">
                            <div class="item-block-img"><img src="assets/images/owl-carousel-image-8-270x320.jpg" alt="img" width="270" height="320">
                            </div>
                            <div class="item-block-social">
                                <ul>
                                    <li><a class="text-gray-270" href="#"><span class="icon mdi mdi-facebook icon-sm"></span></a></li>
                                    <li><a class="text-gray-270" href="#"><span class="icon mdi mdi-twitter icon-sm"></span></a></li>
                                    <li><a class="text-gray-270" href="#"><span class="icon mdi mdi-instagram icon-xs"></span></a></li>
                                </ul>
                            </div>
                            <h5 class="font-weight-sbold ls-1 text-center offset-top-15">Evelyn Brooks</h5>
                            <div class="small-text font-weight-light text-center">Office Manager</div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-4 box-team">
                        <div class="item item-left">
                            <div class="item-block-img"><img src="assets/images/owl-carousel-image-9-270x320.jpg" alt="img" width="270" height="320">
                            </div>
                            <div class="item-block-social">
                                <ul>
                                    <li><a class="text-gray-270" href="#"><span class="icon mdi mdi-facebook icon-sm"></span></a></li>
                                    <li><a class="text-gray-270" href="#"><span class="icon mdi mdi-twitter icon-sm"></span></a></li>
                                    <li><a class="text-gray-270" href="#"><span class="icon mdi mdi-instagram icon-xs"></span></a></li>
                                </ul>
                            </div>
                            <h5 class="font-weight-sbold ls-1 text-center offset-top-15">John Peterson</h5>
                            <div class="small-text font-weight-light text-center">HR Manager</div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</template>

<script>
    export default {
        mounted() {
            
        }
    }
</script>

<style>
    
</style>
