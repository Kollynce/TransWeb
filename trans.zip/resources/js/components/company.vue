<template>
	<div>
	<!-- Breadcrumbs-->
    <section class="breadcrumbs-custom">
        <div class="container">
            <ul class="breadcrumbs-custom-path">
                <li><router-link to="/">Home</router-link></li>
                <li class="active">Company</li>
            </ul>
        </div>
    </section>
	<!-- We stand for fair play and unique ideas -->
	<section class="section overflow-hidden bg-image" style="background-image: url(assets/images/bg-image-1-1920x476.jpg)">
        <div class="container">
            <div class="row">
                <div class="col-lg-7 offset-top-100 text-center text-lg-left">
                    <h2 class="font-weight-sbold wow fadeIn" data-wow-delay=".2s" style="visibility: visible; animation-delay: 0.2s; animation-name: fadeIn;">We provide affordable but quality software solutions in various <br class="d-none d-lg-block"> business sectors!</h2>
                    <h6 class="font-weight-light offset-top-15 wow fadeIn" data-wow-delay=".3s" style="visibility: visible; animation-delay: 0.3s; animation-name: fadeIn;">During our work we developed our approach to providing <span class="font-weight-bold text-primary">products and services</span>,<br class="d-none d-lg-block"> and the strategy of working with our clients.</h6>
                    <div class="group-btn text-center text-lg-left wow fadeIn" data-wow-delay=".4s" style="visibility: visible; animation-delay: 0.4s; animation-name: fadeIn;"><a class="button button-primary button-lg" href="#">get in touch</a><a class="button button-icon button-icon-right button-lg" href="#"><span>Request a call</span><span class="round">
                    <svg width="12" height="12" viewBox="0 0 12 12" fill="">
                      <path d="M11.9943 9.47032C12.0197 9.66526 11.9603 9.83475 11.8164 9.9788L10.1269 11.6567C10.0506 11.7414 9.95114 11.8135 9.82834 11.8728C9.70554 11.9321 9.58488 11.9703 9.46635 11.9872C9.45788 11.9872 9.43242 11.9894 9.39005 11.9936C9.34777 11.9978 9.29272 12 9.22497 12C9.06401 12 8.80357 11.9725 8.44363 11.9174C8.0837 11.8622 7.64333 11.7266 7.12253 11.5106C6.6016 11.2945 6.0109 10.9703 5.35034 10.5381C4.68977 10.106 3.98682 9.51272 3.24155 8.75846C2.64871 8.17371 2.15751 7.61439 1.76793 7.08052C1.37836 6.5466 1.065 6.05296 0.82787 5.59957C0.590716 5.14618 0.412866 4.73516 0.294299 4.36652C0.175733 3.99787 0.0952767 3.68008 0.0529315 3.41313C0.0105863 3.14618 -0.00635178 2.93644 0.00211726 2.78389C0.0105863 2.63135 0.0148208 2.54661 0.0148208 2.52966C0.0317589 2.41101 0.0698696 2.29025 0.129153 2.16737C0.188436 2.04449 0.260423 1.94491 0.345113 1.86864L2.03469 0.177966C2.15325 0.0593219 2.28876 0 2.4412 0C2.5513 0 2.64869 0.0317796 2.73338 0.0953388C2.81807 0.158898 2.89006 0.237288 2.94934 0.330508L4.30862 2.91101C4.38485 3.0466 4.40602 3.19491 4.37214 3.35593C4.33827 3.51694 4.26628 3.65254 4.15618 3.76271L3.53371 4.38559C3.51677 4.40253 3.50195 4.43008 3.48924 4.46821C3.47654 4.50635 3.47019 4.53813 3.47019 4.56355C3.50407 4.74152 3.58029 4.94491 3.69885 5.17372C3.80048 5.37711 3.95716 5.62499 4.16889 5.91736C4.38061 6.20974 4.68126 6.54658 5.07084 6.92793C5.45194 7.3178 5.79071 7.62073 6.08712 7.83687C6.38348 8.05289 6.63128 8.21185 6.8303 8.31355C7.02933 8.41524 7.18177 8.47668 7.28761 8.4978L7.44636 8.5296C7.4633 8.5296 7.49089 8.52323 7.52896 8.51054C7.56707 8.4978 7.59459 8.483 7.61155 8.46603L8.33563 7.72874C8.48816 7.59317 8.66593 7.52537 8.8692 7.52537C9.01322 7.52537 9.12749 7.55077 9.21218 7.60164H9.22486L11.6766 9.05079C11.8545 9.16104 11.9604 9.30083 11.9943 9.47032Z"></path>
                    </svg></span></a></div>
                </div>
                <div class="col-lg-5">
                    <div class="section-img-1 wow fadeInRight" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInRight;"><img src="assets/images/section-img-2-388x458.png" alt="img" width="388" height="458">
                    </div>
                </div>
            </div>
        </div>
    </section>
	<!-- why work with us -->
	<section class="section section-md section-md-2 bg-gray-100">
        <div class="container">
            <div class="row row-40">
                <div class="col-lg-6 wow fadeInUp" data-wow-delay=".01s" style="visibility: visible; animation-delay: 0.01s; animation-name: fadeInUp;"><img src="/images/quiz.jpg" alt="img" width="570" height="373">
                </div>
                <div class="col-lg-6 wow fadeInUp" data-wow-delay=".01s" style="visibility: visible; animation-delay: 0.01s; animation-name: fadeInUp;">
                    <h2 class="font-weight-sbold wow fadeIn" data-wow-delay=".2s" style="visibility: visible; animation-delay: 0.2s; animation-name: fadeIn;">Why choose us?</h2>
                    <h4 class="font-weight-light text-gray-650">We are a command of professional and enthusiastic people, who like what they do.</h4>
                    <div class="row row-15 offset-top-0 offset-top-40">
                        <div class="col-12">
                            <!--Linear progress bar-->
                            <div class="progress-linear animated">
                                <div class="progress-linear-header">
                                    <p class="progress-linear-title font-weight-light text-third">Software Development</p><span class="progress-linear-counter">98</span>
                                </div>
                                <div class="progress-linear-body">
                                    <div class="progress-linear-bar" style="width: 92%;"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <!--Linear progress bar-->
                            <div class="progress-linear animated">
                                <div class="progress-linear-header">
                                    <p class="progress-linear-title font-weight-light text-third">Web Development </p><span class="progress-linear-counter">96</span>
                                </div>
                                <div class="progress-linear-body">
                                    <div class="progress-linear-bar" style="width: 96%;"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <!--Linear progress bar-->
                            <div class="progress-linear animated">
                                <div class="progress-linear-header">
                                    <p class="progress-linear-title font-weight-light text-third">Web Portals</p><span class="progress-linear-counter">94</span>
                                </div>
                                <div class="progress-linear-body">
                                    <div class="progress-linear-bar" style="width: 95%;"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <!--Linear progress bar-->
                            <div class="progress-linear animated">
                                <div class="progress-linear-header">
                                    <p class="progress-linear-title font-weight-light text-third">Wed Design</p><span class="progress-linear-counter">98</span>
                                </div>
                                <div class="progress-linear-body">
                                    <div class="progress-linear-bar" style="width: 95%;"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <!--Linear progress bar-->
                            <div class="progress-linear animated">
                                <div class="progress-linear-header">
                                    <p class="progress-linear-title font-weight-light text-third">IoT </p><span class="progress-linear-counter">95</span>
                                </div>
                                <div class="progress-linear-body">
                                    <div class="progress-linear-bar" style="width: 95%;"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
	<!-- company performance -->
    <section class="section section-xl bg-default">
        <div class="container">
            <div class="row row-40">
                <div class="col-xl-6 text-center text-xl-left offset-top-10 wow fadeInLeft" data-wow-delay=".2s" style="visibility: visible; animation-delay: 0.2s; animation-name: fadeInLeft;">
                    <h2 class="font-weight-sbold">Quick, Smart &amp; Great <br class="d-none d-xl-block"> Solutions</h2>
                    <h4 class="font-weight-light">Transonline Web provides brands with innovative ICT solutions that makes business easier, less risky, and more effective.<br class="d-none d-lg-block"> marketing and analytical services.</h4>
                    <ul class="list-custom-2 text-center text-xl-left offset-top-40-lg">
                        <li><span>
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                      <path d="M8 0C3.56364 0 0 3.56364 0 8C0 12.4364 3.56364 16 8 16C12.4364 16 16 12.4364 16 8C16 3.56364 12.4364 0 8 0ZM12.6182 5.49091L6.8 11.5273C6.72727 11.6 6.65455 11.6364 6.54545 11.6364C6.43636 11.6364 6.32727 11.6 6.29091 11.5273L3.45455 8.47273L3.38182 8.4C3.30909 8.32727 3.27273 8.21818 3.27273 8.14545C3.27273 8.07273 3.30909 7.96364 3.38182 7.89091L3.89091 7.38182C4.03636 7.23636 4.25455 7.23636 4.4 7.38182L4.43636 7.41818L6.43636 9.56364C6.50909 9.63636 6.61818 9.63636 6.69091 9.56364L11.5636 4.50909H11.6C11.7455 4.36364 11.9636 4.36364 12.1091 4.50909L12.6182 5.01818C12.7636 5.12727 12.7636 5.34545 12.6182 5.49091Z" fill="#4173F2"></path>
                    </svg></span><span class="text-third">We have <span class="font-weight-bold">25%</span> projects with good result;</span></li>
                        <li><span>
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                      <path d="M8 0C3.56364 0 0 3.56364 0 8C0 12.4364 3.56364 16 8 16C12.4364 16 16 12.4364 16 8C16 3.56364 12.4364 0 8 0ZM12.6182 5.49091L6.8 11.5273C6.72727 11.6 6.65455 11.6364 6.54545 11.6364C6.43636 11.6364 6.32727 11.6 6.29091 11.5273L3.45455 8.47273L3.38182 8.4C3.30909 8.32727 3.27273 8.21818 3.27273 8.14545C3.27273 8.07273 3.30909 7.96364 3.38182 7.89091L3.89091 7.38182C4.03636 7.23636 4.25455 7.23636 4.4 7.38182L4.43636 7.41818L6.43636 9.56364C6.50909 9.63636 6.61818 9.63636 6.69091 9.56364L11.5636 4.50909H11.6C11.7455 4.36364 11.9636 4.36364 12.1091 4.50909L12.6182 5.01818C12.7636 5.12727 12.7636 5.34545 12.6182 5.49091Z" fill="#4173F2"></path>
                    </svg></span><span class="text-third"><span class="font-weight-bold">75%</span> of our projects have great result.</span></li>
                    </ul>
                </div>
                <div class="col-xl-6 wow fadeInLeft" data-wow-delay=".3s" style="visibility: visible; animation-delay: 0.3s; animation-name: fadeInLeft;">
                    <div class="row row-30 text-center">
                        <div class="col-md-6">
                            <!--Circle progress bar-->
                            <div class="progress-circle animated">
                                <div class="progress-circle-block">
                                    <svg class="progress-circle-bar" x="0" y="0" width="260" height="260" viewBox="0 0 150 150">
                                        <defs>
                                            <linearGradient id="grad1" x1="0%" y1="0%" x2="100%" y2="0%">
                                                <stop offset="0%" stop-color="#4173F2"></stop>
                                                <stop offset="100%" stop-color="#B9CDFF"></stop>
                                            </linearGradient>
                                        </defs>
                                        <circle class="progress-circle-bg" cx="75" cy="75" r="70"></circle>
                                        <circle class="progress-circle-fg clipped" cx="75" cy="75" r="70" clip-path="url(#hdfbcpeh)"></circle>
                                    <clipPath id="qtdgxuih"><path d="M 75 75 L 75 -33 A 108 108 0 0 1 183 75"></path></clipPath><clipPath id="hdfbcpeh"><path d="M 75 75 L 75 -33 A 108 108 0 0 1 75 -33"></path></clipPath></svg>
                                    <div class="progress-circle-counter">25</div>
                                </div>
                                <p class="progress-circle-title">Good Result</p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <!--Circle progress bar-->
                            <div class="progress-circle animated">
                                <div class="progress-circle-block">
                                    <svg class="progress-circle-bar" x="0" y="0" width="260" height="260" viewBox="0 0 150 150">
                                        <defs>
                                            <linearGradient id="grad2" x1="0%" y1="0%" x2="100%" y2="0%">
                                                <stop offset="0%" stop-color="#4173F2"></stop>
                                                <stop offset="100%" stop-color="#B9CDFF"></stop>
                                            </linearGradient>
                                        </defs>
                                        <circle class="progress-circle-bg" cx="75" cy="75" r="70"></circle>
                                        <circle class="progress-circle-fg-2 clipped" cx="75" cy="75" r="70" clip-path="url(#dhsnkagj)"></circle>
                                    <clipPath id="vkagnvhr"><path d="M 75 75 L 75 -33 A 108 108 0 0 1 75 183 A 108 108 0 0 1 -33 75.00000000000001"></path></clipPath><clipPath id="dhsnkagj"><path d="M 75 75 L 75 -33 A 108 108 0 0 1 75 -33"></path></clipPath></svg>
                                    <div class="progress-circle-counter">75</div>
                                </div>
                                <p class="progress-circle-title">Great Result</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 text-center offset-top-20 offset-top-74 wow fadeInRight" data-wow-delay=".2s" style="visibility: visible; animation-delay: 0.2s; animation-name: fadeInRight;"><img src="assets/images/group-img-534x369.png" alt="img" width="534" height="369">
                </div>
                <div class="col-lg-6 text-center text-lg-left block-lg offset-top-74 wow fadeInRight" data-wow-delay=".3s" style="visibility: visible; animation-delay: 0.3s; animation-name: fadeInRight;">
                    <h2 class="font-weight-sbold">Our Company’s Statistics and<br class="d-none d-lg-block"> Achievements</h2>
                    <h4 class="font-weight-light">Since our establishment, we have helped numerous companies increase their profit.</h4>
                    <div class="row">
                        <div class="col-sm-6">
                            <ul class="list-custom-2 text-center text-lg-left offset-top-10">
                                <li><span>
                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                          <path d="M8 0C3.56364 0 0 3.56364 0 8C0 12.4364 3.56364 16 8 16C12.4364 16 16 12.4364 16 8C16 3.56364 12.4364 0 8 0ZM12.6182 5.49091L6.8 11.5273C6.72727 11.6 6.65455 11.6364 6.54545 11.6364C6.43636 11.6364 6.32727 11.6 6.29091 11.5273L3.45455 8.47273L3.38182 8.4C3.30909 8.32727 3.27273 8.21818 3.27273 8.14545C3.27273 8.07273 3.30909 7.96364 3.38182 7.89091L3.89091 7.38182C4.03636 7.23636 4.25455 7.23636 4.4 7.38182L4.43636 7.41818L6.43636 9.56364C6.50909 9.63636 6.61818 9.63636 6.69091 9.56364L11.5636 4.50909H11.6C11.7455 4.36364 11.9636 4.36364 12.1091 4.50909L12.6182 5.01818C12.7636 5.12727 12.7636 5.34545 12.6182 5.49091Z" fill="#4173F2"></path>
                        </svg></span><span class="text-third">2012 — 50% companies</span></li>
                                <li><span>
                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                          <path d="M8 0C3.56364 0 0 3.56364 0 8C0 12.4364 3.56364 16 8 16C12.4364 16 16 12.4364 16 8C16 3.56364 12.4364 0 8 0ZM12.6182 5.49091L6.8 11.5273C6.72727 11.6 6.65455 11.6364 6.54545 11.6364C6.43636 11.6364 6.32727 11.6 6.29091 11.5273L3.45455 8.47273L3.38182 8.4C3.30909 8.32727 3.27273 8.21818 3.27273 8.14545C3.27273 8.07273 3.30909 7.96364 3.38182 7.89091L3.89091 7.38182C4.03636 7.23636 4.25455 7.23636 4.4 7.38182L4.43636 7.41818L6.43636 9.56364C6.50909 9.63636 6.61818 9.63636 6.69091 9.56364L11.5636 4.50909H11.6C11.7455 4.36364 11.9636 4.36364 12.1091 4.50909L12.6182 5.01818C12.7636 5.12727 12.7636 5.34545 12.6182 5.49091Z" fill="#4173F2"></path>
                        </svg></span><span class="text-third">2014 — 70% companies</span></li>
                                <li><span>
                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                          <path d="M8 0C3.56364 0 0 3.56364 0 8C0 12.4364 3.56364 16 8 16C12.4364 16 16 12.4364 16 8C16 3.56364 12.4364 0 8 0ZM12.6182 5.49091L6.8 11.5273C6.72727 11.6 6.65455 11.6364 6.54545 11.6364C6.43636 11.6364 6.32727 11.6 6.29091 11.5273L3.45455 8.47273L3.38182 8.4C3.30909 8.32727 3.27273 8.21818 3.27273 8.14545C3.27273 8.07273 3.30909 7.96364 3.38182 7.89091L3.89091 7.38182C4.03636 7.23636 4.25455 7.23636 4.4 7.38182L4.43636 7.41818L6.43636 9.56364C6.50909 9.63636 6.61818 9.63636 6.69091 9.56364L11.5636 4.50909H11.6C11.7455 4.36364 11.9636 4.36364 12.1091 4.50909L12.6182 5.01818C12.7636 5.12727 12.7636 5.34545 12.6182 5.49091Z" fill="#4173F2"></path>
                        </svg></span><span class="text-third">2015 — 60% companies</span></li>
                            </ul>
                        </div>
                        <div class="col-sm-6">
                            <ul class="list-custom-2 text-center text-lg-left offset-top-10">
                                <li><span>
                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                          <path d="M8 0C3.56364 0 0 3.56364 0 8C0 12.4364 3.56364 16 8 16C12.4364 16 16 12.4364 16 8C16 3.56364 12.4364 0 8 0ZM12.6182 5.49091L6.8 11.5273C6.72727 11.6 6.65455 11.6364 6.54545 11.6364C6.43636 11.6364 6.32727 11.6 6.29091 11.5273L3.45455 8.47273L3.38182 8.4C3.30909 8.32727 3.27273 8.21818 3.27273 8.14545C3.27273 8.07273 3.30909 7.96364 3.38182 7.89091L3.89091 7.38182C4.03636 7.23636 4.25455 7.23636 4.4 7.38182L4.43636 7.41818L6.43636 9.56364C6.50909 9.63636 6.61818 9.63636 6.69091 9.56364L11.5636 4.50909H11.6C11.7455 4.36364 11.9636 4.36364 12.1091 4.50909L12.6182 5.01818C12.7636 5.12727 12.7636 5.34545 12.6182 5.49091Z" fill="#4173F2"></path>
                        </svg></span><span class="text-third">2016 — 70% companies</span></li>
                                <li><span>
                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                          <path d="M8 0C3.56364 0 0 3.56364 0 8C0 12.4364 3.56364 16 8 16C12.4364 16 16 12.4364 16 8C16 3.56364 12.4364 0 8 0ZM12.6182 5.49091L6.8 11.5273C6.72727 11.6 6.65455 11.6364 6.54545 11.6364C6.43636 11.6364 6.32727 11.6 6.29091 11.5273L3.45455 8.47273L3.38182 8.4C3.30909 8.32727 3.27273 8.21818 3.27273 8.14545C3.27273 8.07273 3.30909 7.96364 3.38182 7.89091L3.89091 7.38182C4.03636 7.23636 4.25455 7.23636 4.4 7.38182L4.43636 7.41818L6.43636 9.56364C6.50909 9.63636 6.61818 9.63636 6.69091 9.56364L11.5636 4.50909H11.6C11.7455 4.36364 11.9636 4.36364 12.1091 4.50909L12.6182 5.01818C12.7636 5.12727 12.7636 5.34545 12.6182 5.49091Z" fill="#4173F2"></path>
                        </svg></span><span class="text-third">2018 — 80% companies</span></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
	</div>
</template>

<script>
	export default{

	}
</script>

<style scoped>
	
</style>