<template>
    <div>
        <!-- Breadcrumbs-->
        <section class="breadcrumbs-custom">
            <div class="container">
                <ul class="breadcrumbs-custom-path">
                    <li><router-link to="/">Home</router-link></li>
                    <li class="active">About</li>
                </ul>
            </div>
        </section>
        <!--What we do-->
        <section class="section section-md bg-default">
            <div class="container">
                <div class="row row-40">
                    <div class="col-lg-6 wow fadeInUp" data-wow-delay=".02s" style="visibility: visible; animation-delay: 0.02s; animation-name: fadeInUp;">
                    <h2 class="font-weight-sbold text-center text-lg-left">Challenges are our passion</h2>
                    <h4 class="font-weight-light text-gray-650 text-center text-lg-left">Transonline Web is a global software development company, we specialize in development of innovative and creative products and services. We offer customized software development, web design and development, Search engine optimization services, e-commerce solutions and payment integrations.<br class="d-none d-lg-block"> Our philosophy is to assure the highest quality product, timely delivery of solutions, total client satisfaction and the best price in the industry.</h4>
                    <ul class="list-custom-2 text-center text-lg-left offset-top-40-lg">
                        <li><span>
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M8 0C3.56364 0 0 3.56364 0 8C0 12.4364 3.56364 16 8 16C12.4364 16 16 12.4364 16 8C16 3.56364 12.4364 0 8 0ZM12.6182 5.49091L6.8 11.5273C6.72727 11.6 6.65455 11.6364 6.54545 11.6364C6.43636 11.6364 6.32727 11.6 6.29091 11.5273L3.45455 8.47273L3.38182 8.4C3.30909 8.32727 3.27273 8.21818 3.27273 8.14545C3.27273 8.07273 3.30909 7.96364 3.38182 7.89091L3.89091 7.38182C4.03636 7.23636 4.25455 7.23636 4.4 7.38182L4.43636 7.41818L6.43636 9.56364C6.50909 9.63636 6.61818 9.63636 6.69091 9.56364L11.5636 4.50909H11.6C11.7455 4.36364 11.9636 4.36364 12.1091 4.50909L12.6182 5.01818C12.7636 5.12727 12.7636 5.34545 12.6182 5.49091Z" fill="#4173F2"></path>
                    </svg></span><span class="text-third">Professional support;</span></li>
                        <li><span>
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M8 0C3.56364 0 0 3.56364 0 8C0 12.4364 3.56364 16 8 16C12.4364 16 16 12.4364 16 8C16 3.56364 12.4364 0 8 0ZM12.6182 5.49091L6.8 11.5273C6.72727 11.6 6.65455 11.6364 6.54545 11.6364C6.43636 11.6364 6.32727 11.6 6.29091 11.5273L3.45455 8.47273L3.38182 8.4C3.30909 8.32727 3.27273 8.21818 3.27273 8.14545C3.27273 8.07273 3.30909 7.96364 3.38182 7.89091L3.89091 7.38182C4.03636 7.23636 4.25455 7.23636 4.4 7.38182L4.43636 7.41818L6.43636 9.56364C6.50909 9.63636 6.61818 9.63636 6.69091 9.56364L11.5636 4.50909H11.6C11.7455 4.36364 11.9636 4.36364 12.1091 4.50909L12.6182 5.01818C12.7636 5.12727 12.7636 5.34545 12.6182 5.49091Z" fill="#4173F2"></path>
                    </svg></span><span class="text-third">High-quality consultations;</span></li>
                        <li><span>
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M8 0C3.56364 0 0 3.56364 0 8C0 12.4364 3.56364 16 8 16C12.4364 16 16 12.4364 16 8C16 3.56364 12.4364 0 8 0ZM12.6182 5.49091L6.8 11.5273C6.72727 11.6 6.65455 11.6364 6.54545 11.6364C6.43636 11.6364 6.32727 11.6 6.29091 11.5273L3.45455 8.47273L3.38182 8.4C3.30909 8.32727 3.27273 8.21818 3.27273 8.14545C3.27273 8.07273 3.30909 7.96364 3.38182 7.89091L3.89091 7.38182C4.03636 7.23636 4.25455 7.23636 4.4 7.38182L4.43636 7.41818L6.43636 9.56364C6.50909 9.63636 6.61818 9.63636 6.69091 9.56364L11.5636 4.50909H11.6C11.7455 4.36364 11.9636 4.36364 12.1091 4.50909L12.6182 5.01818C12.7636 5.12727 12.7636 5.34545 12.6182 5.49091Z" fill="#4173F2"></path>
                    </svg></span><span class="text-third">Best specialists;</span></li>
                    </ul>
                </div>
                    <div class="col-lg-6 wow fadeInRight" data-wow-delay=".3s">
                        <!--Bootstrap collapse-->
                        <div class="card-group-custom card-group-custom-2 card-group-corporate" id="accordion1" role="tablist" aria-multiselectable="false">
                            <!--Bootstrap card-->
                            <article class="card card-custom card-corporate card-corporate-2">
                                <div class="card-header" role="tab">
                                    <div class="card-title"><a class="collapsed" id="accordion1-card-head-noywdvpk" data-toggle="collapse" data-parent="#accordion1" href="#accordion1-card-body-nmtfrlvb" aria-controls="accordion1-card-body-nmtfrlvb" aria-expanded="false" role="button">Our Mission
                                        <div class="card-arrow"></div></a></div>
                                </div>
                                <div class="collapse" id="accordion1-card-body-nmtfrlvb" aria-labelledby="accordion1-card-head-noywdvpk" data-parent="#accordion1" role="tabpanel">
                                    <div class="card-body">
                                        <p class="font-weight-light text-gray-770">To be a global software company that provides competitive software solutions that transform lives. </p>
                                    </div>
                                </div>
                            </article>
                            <!--Bootstrap card-->
                            <article class="card card-custom card-corporate card-corporate-2">
                                <div class="card-header" role="tab">
                                    <div class="card-title"><a id="accordion1-card-head-kxnqwbvf" data-toggle="collapse" data-parent="#accordion1" href="#accordion1-card-body-yvlfufio" aria-controls="accordion1-card-body-yvlfufio" aria-expanded="true" role="button">Our Objectives
                                        <div class="card-arrow"></div></a></div>
                                </div>
                                <div class="collapse show" id="accordion1-card-body-yvlfufio" aria-labelledby="accordion1-card-head-kxnqwbvf" data-parent="#accordion1" role="tabpanel">
                                    <div class="card-body">
                                        <p class="font-weight-light text-gray-770">Our main objective is to deliver all our projects in time, providing highly innovative, reliable and maintainable solutions to our customers.</p>
                                    </div>
                                </div>
                            </article>
                            <!--Bootstrap card-->
                            <article class="card card-custom card-corporate card-corporate-2">
                                <div class="card-header" role="tab">
                                    <div class="card-title"><a class="collapsed" id="accordion1-card-head-erdsrrog" data-toggle="collapse" data-parent="#accordion1" href="#accordion1-card-body-tkebygqn" aria-controls="accordion1-card-body-tkebygqn" aria-expanded="false" role="button">Our Vision
                                        <div class="card-arrow"></div></a></div>
                                </div>
                                <div class="collapse" id="accordion1-card-body-tkebygqn" aria-labelledby="accordion1-card-head-erdsrrog" data-parent="#accordion1" role="tabpanel">
                                    <div class="card-body">
                                        <p class="font-weight-light text-gray-770">To provide affordable but quality software solutions in various business sectors and to apply artificial intelligence, big data, robotics, and virtual reality in guaranteeing software transformation.</p>
                                    </div>
                                </div>
                            </article>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--Cost of services of our company-->
        <section class="section section-md bg-default">
            <div class="container">
                <div class="box-video wow fadeInUp" data-wow-delay=".002s"><img class="box-video-image" src="assets/images/aboutus.jpg" alt="img" width="1170" height="480"/><a class="box-video-play" href="https://youtu.be/7dTve2Hsl_0" data-lightgallery="item"></a>
                </div>
                <h2 class="font-weight-sbold wow fadeIn text-center offset-top-40" data-wow-delay=".2s">How we work</h2>
                <h6 class="font-weight-light wow fadeIn text-center" data-wow-delay=".3s">We work efficiently to provide the solutions you need.</h6>
                <div class="row row-30 offset-top-0 offset-top-40 line-decorative">
                    <div class="col-md-6 col-lg-4 text-center text-md-left">
                        <div class="block-lg-5">
                            <div class="small-text font-weight-sbold text-primary circle-block wow fadeInRight" data-wow-delay=".3s">01</div>
                            <div class="offset-top-40-lg">
                                <h5 class="font-weight-sbold ls-1">Meeting With The Customer</h5>
                                <h6 class="font-weight-light text-gray-650">The first meeting is very important to get acquainted and discuss the main ideas of the project.</h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4 text-center text-md-left">
                        <div class="block-lg-5">
                            <div class="small-text font-weight-sbold text-primary circle-block wow fadeInRight" data-wow-delay=".4s">02</div>
                            <div class="offset-top-40-lg">
                                <h5 class="font-weight-sbold ls-1">Work Hard On The Project</h5>
                                <h6 class="font-weight-light text-gray-650">Our professional team starts to work on your project and embody all details of the initial concept.</h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4 text-center text-md-left">
                        <div class="block-lg-5">
                            <div class="small-text font-weight-sbold text-primary circle-block wow fadeInRight" data-wow-delay=".5s">03</div>
                            <div class="offset-top-40-lg">
                                <h5 class="font-weight-sbold ls-1">We Finish The Project</h5>
                                <h6 class="font-weight-light text-gray-650">The project is completed and we give it to our customer. We also ask for customer’s feedback.</h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--Feedback from our customers-->
        <section class="section section-lg bg-gray-100">
            <div class="container">
                <h2 class="font-weight-sbold text-center wow fadeIn" data-wow-delay=".2s">Feedback from our customers</h2>
                <div class="row">
                    <div class="col-md-4">
                        <div class="card" style="width: 18rem;">
                            <img src="../../../public/assets/images/owl-carousel-image-1-270x320.jpg" class="card-img-top" alt="...">
                            <div class="card-body">
                                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card" style="width: 18rem;">
                            <img src="../../../public/assets/images/owl-carousel-image-1-270x320.jpg" class="card-img-top" alt="...">
                            <div class="card-body">
                                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card" style="width: 18rem;">
                            <img src="../../../public/assets/images/owl-carousel-image-1-270x320.jpg" class="card-img-top" alt="...">
                            <div class="card-body">
                                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Partnerships -->
        <section class="section section-xl bg-default">
            <div class="container">
                <h2 class="font-weight-sbold text-center wow fadeIn" data-wow-delay=".2s" style="visibility: visible; animation-delay: 0.2s; animation-name: fadeIn;">Meet our Partners</h2>
                <h6 class="font-weight-light text-center offset-top-10 wow fadeIn" data-wow-delay=".3s" style="visibility: visible; animation-delay: 0.3s; animation-name: fadeIn;">Our team of professionals work hand in hand with our partners to satisfy there needs.</h6>
                <div class="box-client wow fadeInUp pt-5" data-wow-delay=".1s" style="visibility: visible; animation-delay: 0.1s; animation-name: fadeInUp;">
                    <div class="row row-30">
                        <div class="col-sm-4 col-lg-2 text-center">
                            <div class="box-client-item"><a href="#"><img src="assets/images/client-logo-1-150x34.png" alt="img"></a></div>
                        </div>
                        <div class="col-sm-4 col-lg-2 text-center">
                            <div class="box-client-item"><a href="#"><img src="assets/images/client-logo-2-98x28.png" alt="img"></a></div>
                        </div>
                        <div class="col-sm-4 col-lg-2 text-center">
                            <div class="box-client-item"><a href="#"><img src="assets/images/client-logo-3-73x22.png" alt="img"></a></div>
                        </div>
                        <div class="col-sm-4 col-lg-2 text-center">
                            <div class="box-client-item"><a href="#"><img src="assets/images/client-logo-4-100x30.png" alt="img"></a></div>
                        </div>
                        <div class="col-sm-4 col-lg-2 text-center">
                            <div class="box-client-item"><a href="#"><img src="assets/images/client-logo-5-85x40.png" alt="img"></a></div>
                        </div>
                        <div class="col-sm-4 col-lg-2 text-center">
                            <div class="box-client-item"><a href="#"><img src="assets/images/client-logo-6-88x30.png" alt="img"></a></div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</template>

<script>
    export default {
        name: "about"
    }
</script>

<style scoped>

</style>
