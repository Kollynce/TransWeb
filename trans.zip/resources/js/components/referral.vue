<template>
    <div>
        <section class="section section-single pt-5 bg-gray-700">
            <div class="section-single-inner">
                <div class="section-single-main">
                    <div class="container">
                        <h3>We're getting ready to launch</h3>
                        <div class="divider-small"></div>
                        <div class="p-5">
                            <h1>
                                COMMING SOON
                            </h1>
                        </div>
                        <p><span style="max-width: 450px;">Our website is under construction, we are working very hard to give you the best experience on our new web site.</span></p>
                        <div class="rd-mailform-wrap">
                            <form class="rd-form rd-mailform rd-mailform-custom-2 rd-form-inline" data-form-output="form-output-global" data-form-type="subscribe"  >
                                <div class="form-wrap">
                                    <input class="form-input" placeholder="E-mail" id="subscribe-form-email" type="email" name="email" data-constraints="@Email @Required">
                                    <!-- <label class="form-label" for="subscribe-form-email">E-mail</label> -->
                                </div>
                                <div class="form-button">
                                    <button class="button button-primary" type="submit">Subscribe</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</template>

<script>
    export default {
        
    }
</script>
